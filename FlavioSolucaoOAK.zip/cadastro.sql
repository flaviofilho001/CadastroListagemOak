/*
-- Query: SELECT * FROM cadastro
LIMIT 0, 1000

-- Date: 2024-07-16 22:34
*/
INSERT INTO `` (`Id`,`Nome`,`Descricao`,`Valor`,`Disponivel`) VALUES (1,'Bolsa','Bolsa da Chanel',500.000000000000000000000000000000,0);
INSERT INTO `` (`Id`,`Nome`,`Descricao`,`Valor`,`Disponivel`) VALUES (2,'Notebook','Notebook Gamer',1500.000000000000000000000000000000,0);
INSERT INTO `` (`Id`,`Nome`,`Descricao`,`Valor`,`Disponivel`) VALUES (3,'Batom','Batom vermelho',10.000000000000000000000000000000,0);
INSERT INTO `` (`Id`,`Nome`,`Descricao`,`Valor`,`Disponivel`) VALUES (4,'Vaga na Oak','Vaga em empresa excelente de valor imensuravel',10000.000000000000000000000000000000,0);
INSERT INTO `` (`Id`,`Nome`,`Descricao`,`Valor`,`Disponivel`) VALUES (5,'Maquina de Lavar','Maquina de lavar 11 kgs \'',2000.000000000000000000000000000000,0);
