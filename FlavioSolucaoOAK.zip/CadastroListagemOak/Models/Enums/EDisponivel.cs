﻿namespace CadastroListagemOak.Models.Enums
{
    public enum EDisponivel
    {
        sim,
        nao
    }
}
